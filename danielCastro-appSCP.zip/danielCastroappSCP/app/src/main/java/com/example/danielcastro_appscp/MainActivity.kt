package com.example.danielcastro_appscp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.danielcastro_appscp.Scp

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        

        

        val listaSCP = ArrayList<Scp>()

        listaSCP.add(Scp("Julian de pana",3,true))





    }
}