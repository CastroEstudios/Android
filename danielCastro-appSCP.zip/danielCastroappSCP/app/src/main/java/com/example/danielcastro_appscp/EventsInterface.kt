package com.example.danielcastro_appscp

interface EventsInterface {
    fun clickEnElemento(pos: Int)
}