package com.example.danielcastro_appscp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.danielcastro_appscp.Scp
import kotlin.math.absoluteValue


class Adaptador (var listaScp : ArrayList<Scp>, private val mOnClickListener: EventsInterface) : RecyclerView.Adapter<Adaptador.layout_scp>(){

    inner class layout_scp(itemView : View) : RecyclerView.ViewHolder(itemView), View.OnClickListener{

    var imagen : ImageView
    var nombre : TextView
    var descripcion : TextView

    override fun onClick(view : View){
        val position = adapterPosition.absoluteValue
        mOnClickListener.clickEnElemento(position)
    }

    init{
        imagen = itemView.findViewById(R.id.scpImg)
        nombre = itemView.findViewById(R.id.scpNombre)
        descripcion = itemView.findViewById(R.id.scpDesc)
        itemView.setOnClickListener(this)
    }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): layout_scp {
        val item = LayoutInflater.from(parent.context).inflate(R.layout.layout_scp,parent,false)
        return layout_scp(item)
    }

    override fun onBindViewHolder(holder: layout_scp, position: Int) {
        val ScpActual = listaScp[position]
        holder.imagen.setImageResource(ScpActual.numero)
        holder.nombre.text= ScpActual.nombre
        holder.descripcion.text = ScpActual.descripcion
    }

    override fun getItemCount() = listaScp.size

}
