package com.example.quizzapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.delay
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    data class Pregunta(val texto: String, val opciones: Array<String> ,val respuesta: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var listaPreguntas: ArrayList<Pregunta> = ArrayList();

        val pregunta0: Pregunta = Pregunta("PULSE CUALQUIER BOTÓN PARA COMENZAR", arrayOf("COMENZAR", "COMENZAR"), "COMENZAR")
        val pregunta1: Pregunta = Pregunta("¿Qué famoso psicólogo utilizó los arquetipos para desarrollar su tesis?"
        , arrayOf("Jung", "Antonio"), "Jung")
        val pregunta2: Pregunta = Pregunta("¿Qué famoso psicólogo utilizó los arquetipos para desarrollar su tesis?"
            , arrayOf("Jung", "Antoni2o"), "Jung")
        val pregunta3: Pregunta = Pregunta("¿Qué famoso psicólogo utilizó los arquetipos para desarrollar su tesis?"
            , arrayOf("Jung", "Antoni3o"), "Jung")
        val pregunta4: Pregunta = Pregunta("¿Qué famoso psicólogo utilizó los arquetipos para desarrollar su tesis?"
            , arrayOf("Jung", "Antoni4o"), "Jung")

        listaPreguntas.add(pregunta0)
        listaPreguntas.add(pregunta1)
        listaPreguntas.add(pregunta2)
        listaPreguntas.add(pregunta3)
        listaPreguntas.add(pregunta4)

        val buttonRespuesta1: Button = findViewById(R.id.buttonRespuesta1)
        val buttonRespuesta2: Button = findViewById(R.id.buttonRespuesta2)
        val textPregunta: TextView = findViewById(R.id.textView)

        var pregunta: Pregunta = listaPreguntas.get(0)
        buttonRespuesta1.text = pregunta.opciones[0]
        buttonRespuesta2.text = pregunta.opciones[1]

        presionarBotones(buttonRespuesta1, buttonRespuesta2, textPregunta, listaPreguntas);
    }

    fun presionarBotones(buttonRespuesta1: Button, buttonRespuesta2: Button
                         , textPregunta: TextView, listaPreguntas: ArrayList<Pregunta>) {
        var i = 0
        var respuestasCorrectas = 0
        var respuestasIncorrectas = 0;
        var pregunta: Pregunta = listaPreguntas.get(i)

        buttonRespuesta1.setOnClickListener {

            if(buttonRespuesta1.text.equals(pregunta.respuesta)) {
                Toast.makeText(this, "Respuesta correcta", Toast.LENGTH_SHORT).show()
                respuestasCorrectas++
                i++
            }else{
                Toast.makeText(this, "Respuesta INcorrecta", Toast.LENGTH_SHORT).show()
                respuestasIncorrectas++
                i++
            }

            if(i < listaPreguntas.size) {
                pregunta = listaPreguntas.get(i)
                textPregunta.text = pregunta.texto
                buttonRespuesta1.text = pregunta.opciones[0]
                buttonRespuesta2.text = pregunta.opciones[1]
            }

            if(i == listaPreguntas.size) {
                textPregunta.text = "FELICIDADES, HA COMPLETADO EL TRIVIA \n SUS RESULTADOS SON:"
                buttonRespuesta1.text = "CORRECTAS: " + (respuestasCorrectas - 1)
                buttonRespuesta2.text = "CORRECTAS: " + (respuestasIncorrectas)
                i = 0
                respuestasCorrectas = 0
                respuestasIncorrectas = 0;
            }
        }
        buttonRespuesta2.setOnClickListener {
            if(buttonRespuesta2.text.equals(pregunta.respuesta)) {
                Toast.makeText(this, "Respuesta correcta", Toast.LENGTH_SHORT).show()
                respuestasCorrectas++
                i++
            }else{
                Toast.makeText(this, "Respuesta INcorrecta", Toast.LENGTH_SHORT).show()
                respuestasIncorrectas++
                i++
            }
            if(i < listaPreguntas.size) {
                pregunta = listaPreguntas.get(i)
                textPregunta.text = pregunta.texto
                buttonRespuesta1.text = pregunta.opciones[0]
                buttonRespuesta2.text = pregunta.opciones[1]
            }

            if(i == listaPreguntas.size) {
                textPregunta.text = "FELICIDADES, HA COMPLETADO EL TRIVIA \n SUS RESULTADOS SON:"
                buttonRespuesta1.text = "CORRECTAS: " + (respuestasCorrectas - 1)
                buttonRespuesta2.text = "INCORRECTAS: " + (respuestasIncorrectas)
                i = 0
                respuestasCorrectas = 0
                respuestasIncorrectas = 0;
            }
        }

    }
}