package com.example.danielcastro_appscp

data class Scp(var nombre: String,var numero : Int, var descripcion : String)